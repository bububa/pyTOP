#!/usr/bin/env python
# encoding: utf-8
"""
test.py

Created by 徐 光硕 on 2011-11-14.
Copyright (c) 2011 __MyCompanyName__. All rights reserved.
"""

from pyTOP import Users
from pprint import pprint
def main():
    u = Users()
    for user in u.get(['test','hz0799']):
        print user


if __name__ == '__main__':
    main()

